#!/bin/sh
###################################
# start.sh
###################################
# 2013/04/19 (Fri)
###################################
# Yusuke SAITO (NIES-RA)
###################################
source ~/.bashrc
###################################
# set SUFIN, SUFOUT OPTIN & OPTOUT
###################################
# binary to asciiu
#SUFIN=.one
#SUFOUT=.one.txt
#OPTIN=binary
#OPTOUT=asciiu
#
# asciiu to binary
SUFIN=.one.txt
SUFOUT=.one
OPTIN=asciiu
OPTOUT=binary
###################################
# Geoglaphical settings ( Do not edit here)
###################################
L=64800
XY="360 180"
L2X=./data_bin/l2x.one.txt
L2Y=./data_bin/l2y.one.txt
LONLAT="-180 180 -90 90"
ARG="$L $XY $L2X $L2Y $LONLAT"
PRJ=GSWP2
###################################
# JOB conver files (Do not edit here)
###################################
htl2xl2y $L $XY $L2X $L2Y
DIR=./data_bin
NAMES="lndmsk lndara rivara rivnum rivseq flwdir"
for NAME in $NAMES; do
  htformat $ARG $OPTIN $OPTOUT ${DIR}/${NAME}${PRJ}${SUFIN} ${DIR}/${NAME}${PRJ}${SUFOUT}
done

names="C05_____20000000 C05_a___20000000 grdara rivout_1986"
for name in $names; do
  htformat $ARG $OPTIN $OPTOUT ${DIR}/${name}${SUFIN} ${DIR}/${name}${SUFOUT}
done

# Rainf & Tair
PRJ=GSW2
RUN=B1b_

# Rainf
DIR=./data_bin/Rainf___
YEAR=1986
MON=00
DAY=00
htformat $ARG $OPTIN $OPTOUT ${DIR}/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFIN} ${DIR}/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFOUT}

# Tair
DIR=./data_bin/Tair____
YEARS="0000 1986 1987 1988"
DAY=00
for YEAR in $YEARS; do
  if [ $YEAR = 1986 ]; then
    MONS="00 01 02 03 04 05 06 07 08 09 10 11 12"
    for MON in $MONS; do
      htformat $ARG $OPTIN $OPTOUT ${DIR}/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFIN} ${DIR}/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFOUT}
    done
  else
    MON=00
     htformat $ARG $OPTIN $OPTOUT ${DIR}/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFIN} ${DIR}/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFOUT}
  fi
done
