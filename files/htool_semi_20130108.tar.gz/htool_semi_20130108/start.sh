#!/bin/sh
###################################
# start.sh
###################################
# 01/08/2013 (Tue)
###################################
# Yusuke SAITO (NIES-RA)
###################################
source ~/.bashrc
###################################
# set directory of htool_semi
###################################
DIRHTOOL_SEMI=
###################################
L=64800
XY="360 180"
L2X=l2x.one.txt
L2Y=l2y.one.txt
LONLAT="-180 180 -90 90"
SPL="$L $XY $L2X $L2Y $LONLAT"
###################################
cd ${DIRHTOOL_SEMI}/data_bin/
htl2xl2y $L $XY $L2X $L2Y
###################################
SUFIN=.one.txt
SUFOUT=.one
PRJ=.GSWP2
OPIN=asciiu
OPOUT=binary
###################################
NAMES="lndmsk lndara rivara rivnum rivseq flwdir"
for NAME in $NAMES; do
  htformat $SPL $OPIN $OPOUT ${NAME}${PRJ}${SUFIN} ${NAME}${PRJ}${SUFOUT}
done

names="C05_____20000000 C05_a___20000000 grdara rivout_1986"
for name in $names; do
  htformat $SPL $OPIN $OPOUT ${name}${SUFIN} ${name}${SUFOUT}
done

#rm *${SUFIN}
###################################
# convert Rainf & Tair
###################################
PRJ=GSW2
RUN=B1b_

# Rainf
DIR=Rainf___/
YEAR=1986
MON=00
DAY=00
htformat $SPL $OPIN $OPOUT ${DIR}${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFIN} ${DIR}${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFOUT}

# Tair
DIR=Tair____/
YEARS="0000 1986 1987 1988"
DAY=00
for YEAR in $YEARS; do
  if [ $YEAR = 1986 ]; then
    MONS="00 01 02 03 04 05 06 07 08 09 10 11 12"
    for MON in $MONS; do
      htformat $SPL $OPIN $OPOUT ${DIR}${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFIN} ${DIR}${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFOUT}
    done
  else
    MON=00
     htformat $SPL $OPIN $OPOUT ${DIR}${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFIN} ${DIR}${PRJ}${RUN}${YEAR}${MON}${DAY}${SUFOUT}
  fi
done
###########################
rm *${SUFIN}
rm ./Tair____/*${SUFIN}
rm ./Rainf___/*${SUFIN}