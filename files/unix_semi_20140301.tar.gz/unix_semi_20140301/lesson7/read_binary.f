      program read_ascii
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
cto   read ascii file
cby   nahansaki
con   29th Jun 2007
cat   NIES
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      real              data(2,2)
      integer           i,j
c
      open(15,file='sample.bin', access='direct', recl=4*2)
      do j=1,2
        read(15,rec=j) (data(i,j),i=1,2)
      end do
      close(15)
c
      do j=1,2
        write(*,*) (data(i,j),i=1,2)
      end do
c
      end
