#!bin/sh/
##############################################################
# start.sh for unix_semi
##############################################################
# Yusuke SAITO (NIES-RA)
##############################################################
# 2014/02/21(Fri)
##############################################################
# directorys and JOBS setting
##############################################################
DIRS="lesson4 lesson6 lesson8"
JOBS="JOB1 JOB2"                      # for lesson4
NAMES="_DJF _JJA"                     # for lesson4
MAPS="grdara lndara lndmsk pop prc"   # for lesson6 & lesson8
##############################################################
# PRJ, RUN, SUF setting
##############################################################
PRJ=CMAP
RUN=203_
SUF=.cmap
##############################################################
# period setting
##############################################################
YEARMIN=1987
YEARMAX=1988
MONS="00 01 02 03 04 05 06 07 08 09 10 11 12"
DAY=00
##############################################################
# JOBS for lesson4
##############################################################
for DIR in $DIRS; do
  if [ $DIR = lesson4 ]; then
    echo "JOB for lesson4 directory"
# JOB1
    for JOB in $JOBS; do
      echo "JOB=" $JOB
      if [ $JOB = JOB1 ]; then
        YEAR=$YEARMIN
        while [ $YEAR -le $YEARMAX ]; do
          for MON in $MONS; do
	    if [ ! -d dat_bin ]; then
	      mkdir dat_bin
	    fi
	     IN=dat_asc/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUF}.txt
	    OUT=dat_bin/${PRJ}${RUN}${YEAR}${MON}${DAY}${SUF}
	    asc2cmap $IN $OUT
	    echo " IN=" $IN
	    echo "OUT=" $OUT
          done
          YEAR=`expr $YEAR + 1`
        done
	echo "copy those to lesson4"
	cp ./dat_bin/*.cmap ./${DIR}/
	ls ${DIR}/*cmap
# JOB2
      elif [ $JOB = JOB2 ]; then
        YEAR=$YEARMIN
        while [ $YEAR -le $YEARMAX ]; do
          for NAME in $NAMES; do
	     IN=${DIR}/${PRJ}${RUN}${YEAR}${NAME}${SUF}.txt
	    OUT=${DIR}/${PRJ}${RUN}${YEAR}${NAME}${SUF}
	    asc2cmap $IN $OUT
	    echo " IN=" $IN
	    echo "OUT=" $OUT
          done
          YEAR=`expr $YEAR + 1`
        done
      fi
    done
##############################################################
# JOB for lesson6
##############################################################
  elif [ $DIR = lesson6 ]; then
    echo "JOB for lesson6 directory"
    for MAP in $MAPS; do
       IN=${DIR}/${MAP}${SUF}.txt
      OUT=${DIR}/${MAP}${SUF}
      asc2cmap $IN $OUT
      echo " IN=" $IN
      echo "OUT=" $OUT
    done
##############################################################
# JOB for lesson8
##############################################################
  elif [ $DIR = lesson8 ]; then
    echo "JOB for lesson8 directory"
    cp ./lesson6/*.cmap ./${DIR}/
    ls ${DIR}/*.cmap
  fi
done