#################################################################
# Copy and paste below after the last line of your .bashrc
#################################################################
# Set unix_semi directory
# For example, if you put the directory "unix_semi"
# to your home directory, set as below.
#################################################################
DIRUNIX_SEMI=~/unix_semi
#################################################################
# Set PATH
# Add ${DIRUNIX_SEMI}/src to the environmental variable $PATH.
# If you do not understand this for sure, leave below as is.
#################################################################
PATH=.:${PATH}:${DIRUNIX_SEMI}/src
#################################################################
# Set FORTRAN
# If you are using intel fortran compiler, remove "#" 
# at the begining of the line.
#################################################################
#alias ifort='ifort -assume byterecl'
#################################################################