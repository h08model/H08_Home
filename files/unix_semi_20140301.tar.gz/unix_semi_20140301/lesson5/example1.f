      program sample
c
* this is comment
c
      write(*,*) 'hello world.'
      write(*,*) 'Very very long sentences sentences such as this must
     $ be divided in two lines'
c
      end
