# simple
avecmap prc.cmap 0
# correct
procmap prc.cmap grdara.cmap temp.prcXgrdara.cmap
sumcmap temp.prcXgrdara.cmap 0
sumcmap grdara.cmap 0
A=`sumcmap temp.prcXgrdara.cmap 0`
B=`sumcmap grdara.cmap 0`
echo $A  $B | awk '{print $1/$2}'