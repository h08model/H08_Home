      program maxcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   find the maximum value in an array
cby   nhanasaki
con   20th Jul 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      real              plonmin
      real              plonmax
      real              platmin
      real              platmax
      parameter        (nx=144)
      parameter        (ny=72)
      parameter        (plonmin=-180)
      parameter        (plonmax=180)
      parameter        (platmin=-90)
      parameter        (platmax=90)
c index
      integer           ix
      integer           iy
c temporary
      character*128     ctmp            !! dummy
      real              rtmp
c function
      integer           iargc
c in
      real              rdat(nx,ny)     !! matrix DATA
c out
      integer           ixrec
      integer           iyrec
      real              rlonrec
      real              rlatrec                     

      real              rmaxrec
c file
      character*128     cifname         !! Input File NAME
c to be revisited
      real              rmis
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.2) then
        write(*,*) 'Usage: maxcmap Infile missing_number '
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,ctmp)
      read(ctmp,*) rmis
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      rmaxrec=-9.99E20
      do iy=1,ny
        do ix=1,nx
          if(rdat(ix,iy).ne.rmis)then
            rtmp=max(rdat(ix,iy),rmaxrec)
            if(rtmp.gt.rmaxrec)then
              rmaxrec=rtmp
              ixrec=ix
              iyrec=iy
            end if
          end if
        end do
      end do
c
      rlonrec=plonmin+(plonmax-plonmin)/real(nx)*(real(ixrec)-0.5)
      rlatrec=platmax-(platmax-platmin)/real(ny)*(real(iyrec)-0.5)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      write(*,*) rmaxrec,rlonrec,rlatrec,ixrec,iyrec
c
      end

