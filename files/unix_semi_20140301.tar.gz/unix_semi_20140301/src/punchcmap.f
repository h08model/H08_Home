      program punchcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   pick up (x,y) data from 144x72 binary
cby   nhanasaki
con   13th Aug 2002
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      real              plonmin
      real              platmin
      real              plonmax
      real              platmax
      real              pgrd
      parameter        (nx=144)
      parameter        (ny=72)
      parameter        (plonmin=-180)
      parameter        (platmin=-90)
      parameter        (plonmax=180)
      parameter        (platmax=90)
c index
      integer           ix
      integer           iy
c temporary
      real              rtmp
      character*128     ctmp
c function
      integer           iargc
      integer           igetday
c in
      real              rlon
      real              rlat
      real              rdat(nx,ny)
      real              rara(nx,ny)
      integer           imsk(nx,ny)
c out
      real              rout
c file
      character*128     cifname
      character*128     corg
      character*128     crun
      character*128     csuf
      character*128     copt             !! Option
      character*128     cmsk
      character*128     cara
      data              csuf/'.cmap'/ 
c
      integer           iyear
      integer           iyearmin
      integer           iyearmax
      integer           imon
      integer           imonmin
      integer           imonmax
      integer           iday
      integer           idaymin
      integer           idaymax
      integer           idayint
      integer           ihour
      integer           ihourmax
      integer           ihourint
      integer           iyear2
      integer           imon2
      integer           iday2
      integer           ihour2
c local
      integer           ixpnt
      integer           iypnt
      real              rdatsum
      real              rarasum
      integer           iswt
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.7.and.iargc().ne.9) then
        write(*,*) 'Usage: punchone exp run yearmin yearmax lon lat '
        write(*,*) 'opt1 <opt2> <opt3>'
        write(*,*) 'opt1: year or mon or day or 3hr or day30'
        write(*,*) 'opt2: maskfile 0/1'
        write(*,*) 'opt3: areafile'
        write(*,*) 'Warning, skip lon/lat if you set opt2 and opt3'
        stop
      end if
c
      call getarg(1,corg)
      call getarg(2,crun)
      call getarg(3,ctmp)
      read(ctmp,*) iyearmin              
      call getarg(4,ctmp)
      read(ctmp,*) iyearmax              
      call getarg(5,ctmp)
      read(ctmp,*) rlon
      call getarg(6,ctmp)
      read(ctmp,*) rlat
      call getarg(7,copt)
      if(iargc().eq.9)then
        call getarg(8,cmsk)
        call read_binmat(rtmp,nx,ny,15,cmsk)
        call conv_rmtoim(rtmp,imsk,nx,ny)
        call getarg(9,cara)
        call read_binmat(rara,nx,ny,15,cara)
        iswt=1
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      ixpnt=int((rlon-plonmin)/(plonmax-plonmin)*real(nx)+0.5)
      iypnt=int((platmax-rlat)/(platmax-platmin)*real(ny)+0.5)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c 
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      do iyear=iyearmin,iyearmax
        if(copt.eq.'year')then
          imonmin=0
          imonmax=0
        else
          imonmin=1
          imonmax=12
        end if
        do imon=imonmin,imonmax
          if(copt.eq.'day'.or.copt.eq.'noleap'.or.
     $       copt.eq.'6hr'.or.copt.eq.'3hr')then
            idaymin=1
            idaymax=igetday(iyear,imon)
            if(copt.eq.'noleap'.and.idaymax.eq.29)then
              idaymax=28
            end if
          else if(copt.eq.'day30')then
            idaymin=1
            idaymax=30            
          else if(copt.eq.'dec')then
            idaymin=1
            idaymax=21
          else
            idaymin=0
            idaymax=0
          end if
          if(copt.eq.'dec')then
            idayint=10
          else
            idayint=1
          end if
          do iday=idaymin,idaymax,idayint
            if(copt.eq.'3hr'.or.copt.eq.'6hr')then
              if(copt.eq.'3hr')then
                ihourmax=21
                ihourint=3                
              else if(copt.eq.'6hr')then
                ihourmax=18
                ihourint=6
              end if
              do ihour=ihourint,24,ihourint
                iyear2=iyear
                imon2=imon
                iday2=iday
                ihour2=ihour
                if(ihour2.eq.24)then
                  ihour2=0
                  iday2=iday2+1
                  if(iday2.gt.igetday(iyear2,imon2))then
                    iday2=1
                    imon2=imon2+1
                    if(imon2.gt.12)then
                      imon2=1
                      iyear2=iyear2+1
                    end if
                  end if
                end if
                write(cifname,'(a4,a4,i4.4,i2.2,i2.2,i2.2,a5)')
     $               corg,crun,iyear2,imon2,iday2,ihour2,csuf
                if(iswt.eq.1)then
                  call read_binmat(rdat,nx,ny,15,cifname)
                  rdatsum=0
                  rarasum=0
                  do iy=1,ny
                    do ix=1,nx
                      if(imsk(ix,iy).ne.0)then
                        rdatsum=rdatsum+rdat(ix,iy)*rara(ix,iy)
                        rarasum=rarasum+rara(ix,iy)
                      end if
                    end do
                  end do
                  rout=rdatsum/rarasum
                else
          open(15,file=cifname,access='direct',status='old',recl=nx*4)
                  iy=iypnt
                  read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
                  rout=rdat(ixpnt,iypnt)
                  close(15)
                end if
                write(*,*) iyear,imon,iday,ihour,rout
              end do
            else
              write(cifname,'(a4,a4,i4.4,i2.2,i2.2,a5)')
     $             corg,crun,iyear,imon,iday,csuf
              if(iswt.eq.1)then
                call read_binmat(rdat,nx,ny,15,cifname)
                rdatsum=0
                rarasum=0
                do iy=1,ny
                  do ix=1,nx
                    if(imsk(ix,iy).ne.0)then
                      rdatsum=rdatsum+rdat(ix,iy)*rara(ix,iy)
                      rarasum=rarasum+rara(ix,iy)
                    end if
                  end do
                end do
                rout=rdatsum/rarasum
              else
          open(15,file=cifname,access='direct',status='old',recl=nx*4)
                iy=iypnt
                read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
                close(15)
                rout=rdat(ixpnt,iypnt)
              end if
              write(*,*) iyear,imon,iday,rout
            end if
          end do
        end do
      end do
c
      end

      integer function igetday(iyear,imon)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   count number of days in month
cby   nhanasaki
con   20th Dec 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c in
      integer           iyear
      integer           imon
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation for months except February
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(imon.eq.4.or.imon.eq.6.or.imon.eq.9.or.imon.eq.11)then
        igetday=30
      else
        igetday=31
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation for February
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(imon.eq.2)then
        if(mod(iyear,4).eq.0)then
          igetday=29
          if(mod(iyear,100).eq.0)then
            igetday=28
            if(mod(iyear,400).eq.0)then
              igetday=29
            end if
          end if
        else
          igetday=28
        end if
      end if
c
      if(iyear.eq.0.and.imon.eq.2)then
        igetday=28
      end if
c
      end
      subroutine read_binmat(rdat,nx,ny,infile,cfname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   read binary matrix file
cby   nhanasaki
con   22th Aug 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c
      integer          ix,iy
      integer          nx,ny
      integer          infile
      real             rdat(nx,ny)
      character*128    cfname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(infile,file=cfname,access='DIRECT',status='old',recl=4*nx)
      do iy = 1,ny
        read (infile,rec=iy)(rdat(ix,iy),ix=1,nx)
      end do
      close (infile)
c
      end
      subroutine conv_rmtoim(rdat,idat,nx,ny)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   convert real matrix to integer matrix
cby   Taikan, OKI, modified by nhanasaki
con   25th Apr 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      integer nx,ny
      integer i,j
      integer idat(nx,ny)
      real    rdat(nx,ny)
c
      do i=1,nx
        do j=1,ny
          idat(i,j)=int(rdat(i,j))
        end do
      end do
c
      end
      
