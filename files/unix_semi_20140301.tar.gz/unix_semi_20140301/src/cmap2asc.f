      program cmap2asc
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
cto   Convert binary (144x72) to ascii
con   30th/May/2002
cby   nhanasaki
cat   IIS, UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      implicit none
c parameter
      integer           nx
      integer           ny
      parameter        (nx=144)
      parameter        (ny=72)
c index
      integer           ix
      integer           iy
c function
      integer           iargc
c in
      real              rdat(nx,ny)
c file
      character*128     cifname
      character*128     cofname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Get file name
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if (iargc().ne.2) then
        write(*,*) 'Usage: cmap2asc Infile Outfile'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy),ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Write
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      open(16,file=cofname, access='sequential')
      do iy=1,ny
        write(16,*) (rdat(ix,iy),ix=1,nx)
      end do
      close(16)
c
      end



