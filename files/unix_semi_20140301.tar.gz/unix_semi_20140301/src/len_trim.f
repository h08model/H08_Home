      integer function len_trim(char)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   count the length of character
cby   somebody
con   sometime
cat   somewhere
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      character*(*)     char
      integer           i
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      do i=1,len(char)
        if(char(i:i).eq.' ')then
          len_trim=i-1
          return
        end if
      end do
      len_trim=len(char)
c
      end
