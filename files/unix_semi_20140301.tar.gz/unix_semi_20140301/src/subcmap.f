      program subcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
cto	subtract an array from an array
con	31/May/2002
cby	nhanasaki
cat	IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      implicit none
c parameter
      integer           nx
      integer           ny
      parameter        (nx=144) 
      parameter        (ny=72) 
c index
      integer           ix
      integer           iy
c function
      integer           iargc
c in
      real              rdat1(nx,ny)
      real              rdat2(nx,ny)
c out
      real              rout(nx,ny)
c file
      character*128     cifname1
      character*128     cifname2
      character*128     cofname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Get File Names
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if (iargc().ne.3) then
        write(*,*) 'Usage: subcmap Infile1 Infile2 Outfile'
        stop
      end if
c
      call getarg(1,cifname1)
      call getarg(2,cifname2)
      call getarg(3,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      open(15,file=cifname1,access='DIRECT',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat1(ix,iy),ix=1,nx)
      end do
      close(15)
c
      open(15,file=cifname2,access='DIRECT',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat2(ix,iy),ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Calculation
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      do ix=1,nx
        do iy=1,ny
          rout(ix,iy)=rdat1(ix,iy)-rdat2(ix,iy)
        end do
      end do
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Write Outfile
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      open(16,file=cofname,access='DIRECT',recl=nx*4)
      do iy=1,ny
        write(16,rec=iy) (rout(ix,iy),ix=1,nx)
      end do
      close(16)
c
      end














