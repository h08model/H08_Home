      program mon2yearcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
cto   convert monthly data into yearly data
cby   nhanasaki
con   6th Jan 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      implicit none
c parameter
      integer           nx
      integer           ny
      parameter        (nx=144)
      parameter        (ny=72)
c index
      integer           ix
      integer           iy
      integer           iyear
      integer           iyearmin
      integer           iyearmax
      integer           imon
c temporary
      character*128     ctmp
c function
      integer           iargc           !! Default function
      integer           igetday         !! Original function
      integer           len_trim        !! Original function
c in
      real              rmondat(nx,ny)  !! Monthly data array
c out
      real              ranudat(nx,ny)  !! Annual data array
c local
      integer           inofdaymon      !! Number of days in a month
      integer           inofdayyear     !! Number of days in a year
c file
      character*128     cdir
      character*128     cexp
      character*128     crun
      character*128     csuf
      character*128     cifname
      character*128     cofname
      integer           ilen
      character*128     clen
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Get Arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if(iargc().ne.6)then
        write(*,*) 'mon2year dir exp run yearmin yearmax suf'
        stop
      end if
c
      call getarg(1,cdir)
      call getarg(2,cexp)
      call getarg(3,crun)
      call getarg(4,ctmp)
      read(ctmp,*) iyearmin
      call getarg(5,ctmp)
      read(ctmp,*) iyearmax
      call getarg(6,csuf)
c
      ilen=len_trim(cdir)
      write(clen,*) ilen
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Sum up
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      do iyear=iyearmin,iyearmax
c clear variable
        inofdayyear=0
c clear array
        do iy=1,ny
          do ix=1,nx
            ranudat(ix,iy)=0.0
          end do
        end do
c
        do imon=1,12
          inofdaymon=igetday(iyear,imon)
          inofdayyear=inofdayyear+inofdaymon
c read data
          write(cifname,'(a'//clen//',a4,a4,i4.4,i2.2,i2.2,a5)') 
     $    cdir,cexp,crun,iyear,imon,0,csuf
          call read_binmat(rmondat,nx,ny,15,cifname)
c          open(15,file=cifname,access='direct',status='old',recl=4*nx)
c          do iy=1,ny
c            read(15,rec=iy) (rmondat(ix,iy),ix=1,nx)
c          end do
c          close(15)
c calclulation
          do iy=1,ny
            do ix=1,nx
              ranudat(ix,iy)
     $       =ranudat(ix,iy)+rmondat(ix,iy)*real(inofdaymon)
            end do
          end do
        end do
c Get average
        do iy=1,ny
          do ix=1,nx
            ranudat(ix,iy)=ranudat(ix,iy)/real(inofdayyear)
          end do
        end do
c Write results
        write(cofname,'(a'//clen//',a4,a4,i4.4,i2.2,i2.2,a5)')
     $  cdir,cexp,crun,iyear,0,0,csuf 
        call wrte_binmat(ranudat,nx,ny,16,cofname)
c        open(16,file=cofname,access='direct',recl=4*nx)
c        do iy=1,ny
c          write(16,rec=iy) (ranudat(ix,iy),ix=1,nx)
c        end do
c        close(16)
      end do
c
      end
