      program maskcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   pickup data from an array if the mask meet a condition
cby   nhanasaki
con   13th Aug 2002
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      parameter        (nx=144)
      parameter        (ny=72)
c index
      integer           ix
      integer           iy
c temporary
      character*128     ctmp      !! temporary
c function
      integer           iargc
c in
      real              rnum
      character*128     csgn      !! option
      real              rdat(nx,ny)
      real              rmsk(nx,ny)
c out
      integer           icnt
      real              rout(nx,ny)
c file
      character*128     cmfname   !! Mask FILE
      character*128     cifname   !! Input FILE
      character*128     cofname   !! Output FILE
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.5) then
        write(*,*) 'Usage: maskcmap Infile Maskfile Sgn Real_num Outfil'
        write(*,*) 'Sgn:  eq ne lt le gt ge'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,cmfname)
      call getarg(3,csgn)
      call getarg(4,ctmp)
      read(ctmp,*) rnum
      call getarg(5,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read Dat1 & Dat2  
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cmfname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rmsk(ix,iy), ix=1,nx)
      end do
      close(15)
c
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write pickuped dat
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      icnt=0
      do iy=1,ny
        do ix=1,nx
          rout(ix,iy)=0.0
        end do
      end do
      if(csgn.eq.'lt')then
        do iy=1,ny
          do ix=1,nx
            if(rmsk(ix,iy).lt.rnum) then
              rout(ix,iy)=rdat(ix,iy)
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'There are ',icnt,' data less than ',rnum
      else if(csgn.eq.'le')then
        do iy=1,ny
          do ix=1,nx
            if(rmsk(ix,iy).le.rnum) then
              rout(ix,iy)=rdat(ix,iy)
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'There are ',icnt,' data less equal ',rnum
      else if(csgn.eq.'gt')then
        do iy=1,ny
          do ix=1,nx
            if(rmsk(ix,iy).gt.rnum) then
              rout(ix,iy)=rdat(ix,iy)
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'There are ',icnt,' data greater than ',rnum
      else if(csgn.eq.'ge')then
        do iy=1,ny
          do ix=1,nx
            if(rmsk(ix,iy).ge.rnum) then
              rout(ix,iy)=rdat(ix,iy)
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'There are ',icnt,' data greater equal ',rnum
      else if(csgn.eq.'ne')then
        do iy=1,ny
          do ix=1,nx
            if(rmsk(ix,iy).ne.rnum) then
              rout(ix,iy)=rdat(ix,iy)
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'There are ',icnt,' data not equal to ',rnum
      else if(csgn.eq.'eq')then
        do iy=1,ny
          do ix=1,nx
            if(rmsk(ix,iy).eq.rnum) then
              rout(ix,iy)=rdat(ix,iy)
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'There are ',icnt,' data equal to ',rnum
      else
        write(*,*) 'Sign',csgn,'is not valid Abort.'
        stop
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      open(16,file=cofname,access='direct',recl=nx*4)
      do iy=1,ny
        write(16,rec=iy) (rout(ix,iy), ix=1,nx)
      end do
      close(16)
c      
      end
