      program shiftcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   shift 180 degree eastward of an array
cby   nhanasaki
con   26th Oct 2002
cat   IIS, UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer       nx
      integer       ny
      parameter    (nx=144)
      parameter    (ny=72)
c index
      integer       ix
      integer       iy
c in
      real          rdat(nx,ny)
c out
      real          rout(nx,ny)
c file
      character*128 cifname
      character*128 cofname
c function
      integer       iargc
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c     Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.2)then
        write(*,*) 'Usage: shiftone INBIN OUTBIN'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=4*nx)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy),ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      do iy=1,ny
        do ix=1,nx/2
          rout(ix,iy)=rdat(ix+nx/2,iy)
        end do
      end do
c
      do iy=1,ny
        do ix=nx/2+1,nx
          rout(ix,iy)=rdat(ix-nx/2,iy)
        end do
      end do
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(16,file=cofname,access='direct',recl=4*nx)
      do iy=1,ny
        write(16,rec=iy) (rout(ix,iy),ix=1,nx)
      end do
      close(16)
c
      end



