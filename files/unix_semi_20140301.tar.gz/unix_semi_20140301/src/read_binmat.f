      subroutine read_binmat(rdat,nx,ny,infile,cfname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   read binary matrix file
cby   nhanasaki
con   22th Aug 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      integer          nx, ny
      integer          infile
      real             rdat(nx, ny)
      character*128    cfname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(infile,file=cfname,access='DIRECT',status='old',recl=4*nx)
      do j = 1,ny
        read (infile,rec=j)(rdat(i,j),i=1,nx)
      end do
      close (infile)
c
      end
