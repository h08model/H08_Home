      subroutine wrte_binmat(rdat,nx,ny,iofile,cfname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   write binary matrix file
cby   Taikan, OKI, modified by nhanasaki
con   ??,25th Apr 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      integer        nx,ny
      integer        iofile
      real           rdat(nx, ny)
      character*128  cfname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write binary
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(iofile, file=cfname, access='DIRECT', recl=nx*4)
      do j = 1, ny
        write (iofile, rec=j) (rdat(i, j), i = 1, nx)
      end do
      close(iofile)
c
      end
