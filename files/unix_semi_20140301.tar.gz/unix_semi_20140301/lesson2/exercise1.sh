who > temp.wholist.txt

cal 2004 >  temp.cal.txt
cal 2005 >> temp.cal.txt