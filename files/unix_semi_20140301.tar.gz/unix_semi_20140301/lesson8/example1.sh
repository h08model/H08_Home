#!/bin/sh
############################################################
MONS="01 02 03 04 05 06 07 08 09 10 11 12"
BIRTHMON="08"
############################################################
for MON in $MONS; do
  if [ $MON = $BIRTHMON ]; then
    echo $MON "Happy birth month!"
  else
    echo $MON
  fi
done
