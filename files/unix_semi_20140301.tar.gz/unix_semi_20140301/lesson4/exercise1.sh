# ATTENTION:
# DJF (December, January, and February) for 1987 usually indicates 
# December 1987-February 1988, or December 1986-February 1987. 
# In this exercise, to reduce the total number of monthly precipitation files, 
# only the files from January 1987to December 1988 are used.
# Therefore, the example below assumes DJF for 1987 as the mean of 
# January, February, and December in 1987, which contains an apparent 
# discontinuity. If you can handle longer data including 1986 or 1989,
# please make the monthly time series continuous.

createcmap CMAP203_1987_JJA.cmap 0
addcmap    CMAP203_19870600.cmap CMAP203_1987_JJA.cmap CMAP203_1987_JJA.cmap
addcmap    CMAP203_19870700.cmap CMAP203_1987_JJA.cmap CMAP203_1987_JJA.cmap
addcmap    CMAP203_19870800.cmap CMAP203_1987_JJA.cmap CMAP203_1987_JJA.cmap
divcmap    CMAP203_1987_JJA.cmap 3                     CMAP203_1987_JJA.cmap

createcmap CMAP203_1988_JJA.cmap 0
addcmap    CMAP203_19880600.cmap CMAP203_1988_JJA.cmap CMAP203_1988_JJA.cmap
addcmap    CMAP203_19880700.cmap CMAP203_1988_JJA.cmap CMAP203_1988_JJA.cmap
addcmap    CMAP203_19880800.cmap CMAP203_1988_JJA.cmap CMAP203_1988_JJA.cmap
divcmap    CMAP203_1988_JJA.cmap 3                     CMAP203_1988_JJA.cmap

subcmap    CMAP203_1987_JJA.cmap CMAP203_1988_JJA.cmap temp.JJA.cmap
cmap2eps   temp.JJA.cmap         dif.cpt               temp.JJA.eps

createcmap CMAP203_1987_DJF.cmap 0
addcmap    CMAP203_19871200.cmap CMAP203_1987_DJF.cmap CMAP203_1987_DJF.cmap
addcmap    CMAP203_19870100.cmap CMAP203_1987_DJF.cmap CMAP203_1987_DJF.cmap
addcmap    CMAP203_19870200.cmap CMAP203_1987_DJF.cmap CMAP203_1987_DJF.cmap
divcmap    CMAP203_1987_DJF.cmap 3                     CMAP203_1987_DJF.cmap

createcmap CMAP203_1988_DJF.cmap 0
addcmap    CMAP203_19881200.cmap CMAP203_1988_DJF.cmap CMAP203_1988_DJF.cmap
addcmap    CMAP203_19880100.cmap CMAP203_1988_DJF.cmap CMAP203_1988_DJF.cmap
addcmap    CMAP203_19880200.cmap CMAP203_1988_DJF.cmap CMAP203_1988_DJF.cmap
divcmap    CMAP203_1988_DJF.cmap 3                     CMAP203_1988_DJF.cmap

subcmap    CMAP203_1987_DJF.cmap CMAP203_1988_DJF.cmap temp.DJF.cmap
cmap2eps   temp.DJF.cmap         dif.cpt               temp.DJF.eps